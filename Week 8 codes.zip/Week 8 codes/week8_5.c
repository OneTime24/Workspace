#include <stdio.h>

int main() 
{
    int ar[5];	// Array declaration

	// Array initialization, the long way
    ar[0] = 14;
    ar[1] = 12;
    ar[2] = 15;
    ar[3] = 33;
    ar[4] = 22;
    
    printf("%d, %d, %d, %d, %d\n", 
			ar[0], ar[1], ar[2], ar[3], ar[4]);

    return 0;
}


